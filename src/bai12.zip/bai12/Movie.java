package bai12;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Movie implements Comparable<Movie> {
    private String movieID;
    private String movieName;
    private Date releaseDate;
    private int episodes;
    private MovieType movieType;

    private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    public Movie(String movieID, MovieType movieType, String releaseDate, String movieName, int episodes) throws ParseException {
        this.movieID = movieID;
        this.movieName = movieName;
        this.releaseDate = dateFormat.parse(releaseDate);
        this.episodes = episodes;
        this.movieType = movieType;
    }
    public String getMovieID(){
        return movieID;
    }
    public MovieType getMovieType(){
        return movieType;
    }
    public Date getReleaseDate(){
        return releaseDate;
    }
    public String getMovieName(){
        return movieName;
    }
    public int getEpisodes(){
        return episodes;
    }

    @Override
    public int compareTo(Movie o) {
        int cmp = this.releaseDate.compareTo(o.getReleaseDate());
        if(cmp != 0){
            return cmp;
        }
        int cmpName = this.movieName.compareTo(o.getMovieName());
        if(cmpName != 0){
            return cmpName;
        }
        return Integer.compare(o.episodes, this.episodes);
    }

    @Override
    public String toString() {
        return movieID + " " + movieType.getTypeName() + " " + dateFormat.format(releaseDate) + " " + movieName + " " + episodes;
    }
}
