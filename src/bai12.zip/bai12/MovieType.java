package bai12;

public class MovieType {
    private String typeID;
    private String typeName;

    public MovieType(String typeID, String typeName){
        this.typeID = typeID;
        this.typeName = typeName;
    }
    public String getTypeID(){
        return typeID;
    }
    public String getTypeName(){
        return typeName;
    }
}

