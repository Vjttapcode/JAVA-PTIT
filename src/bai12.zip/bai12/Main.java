package bai12;
import java.text.ParseException;
import java.util.*;

public class Main {
    public static void main(String[] args) throws ParseException {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        sc.nextLine();
        List<MovieType> danhSachTheLoai = new ArrayList<>();
        for(int i=1; i<=n; i++){
            String typeName = sc.nextLine();
            String typeID = String.format("TL%03d", i);
            danhSachTheLoai.add(new MovieType(typeName, typeID));
        }
        List<Movie> danhSachPhim = new ArrayList<>();
        for(int i=1; i<=m; i++){
            String typeID = sc.nextLine();
            String releaseDate = sc.nextLine();
            sc.nextLine();
            String title = sc.nextLine();
            int episodes = sc.nextInt();
            if(sc.hasNextLine()){
                sc.nextLine();
            }
            MovieType movieType = null;
            for(MovieType tl : danhSachTheLoai){
                if(tl.getTypeID().equals(typeID)){
                    movieType = tl;
                    break;
                }
            }
            String movieID = String.format("P%03d",i);
            Movie movie = new Movie(movieID, movieType, releaseDate, title, episodes);
            danhSachPhim.add(movie);
        }
        Collections.sort(danhSachPhim);
        for(Movie p : danhSachPhim){
            System.out.println(p);
        }
        sc.close();
    }
}
